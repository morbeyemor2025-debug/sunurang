import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import { nanoid } from "nanoid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── In-memory store (MVP — remplacer par Supabase en Phase 2) ───────────────
interface Client {
  id: string;
  name: string;
  phone: string;  // numéro WhatsApp sans le +
  position: number;
  joinedAt: Date;
  status: "waiting" | "called" | "done";
  notified: boolean;
}

interface Salon {
  id: string;
  name: string;
  slug: string;
  queue: Client[];
  currentServing: number; // compteur total servis aujourd'hui
}

// Salons de démo pré-chargés
const salons: Map<string, Salon> = new Map([
  ["salon-alpha", {
    id: "salon-alpha",
    name: "Salon Alpha Coiffure",
    slug: "alpha",
    queue: [],
    currentServing: 0,
  }],
  ["salon-demo", {
    id: "salon-demo",
    name: "Salon Teranga Beauté",
    slug: "demo",
    queue: [],
    currentServing: 0,
  }],
]);

// SSE clients (pour le temps réel)
const sseClients: Map<string, Set<express.Response>> = new Map();

function broadcastToSalon(salonId: string, data: object) {
  const clients = sseClients.get(salonId);
  if (!clients) return;
  const msg = `data: ${JSON.stringify(data)}\n\n`;
  clients.forEach(res => {
    try { res.write(msg); } catch { clients.delete(res); }
  });
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // ─── API Routes ────────────────────────────────────────────────────────────

  // GET /api/health — Railway healthcheck
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", ts: new Date().toISOString() });
  });

  // GET /api/salons/:id — infos salon + file
  app.get("/api/salons/:id", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });
    const waiting = salon.queue.filter(c => c.status === "waiting");
    res.json({
      id: salon.id,
      name: salon.name,
      waitingCount: waiting.length,
      estimatedWait: waiting.length * 20, // 20 min par client
      queue: salon.queue.map(c => ({
        id: c.id,
        name: c.name,
        position: c.position,
        status: c.status,
        joinedAt: c.joinedAt,
      })),
    });
  });

  // POST /api/salons/:id/join — rejoindre la file
  app.post("/api/salons/:id/join", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const { name, phone } = req.body;
    if (!name || !phone) return res.status(400).json({ error: "Nom et téléphone requis" });

    // Vérifier si déjà dans la file
    const existing = salon.queue.find(c => c.phone === phone && c.status === "waiting");
    if (existing) {
      return res.json({ client: existing, salon: { name: salon.name }, alreadyInQueue: true });
    }

    const waiting = salon.queue.filter(c => c.status === "waiting");
    const client: Client = {
      id: nanoid(8),
      name: name.trim(),
      phone: phone.replace(/\D/g, ""),
      position: waiting.length + 1,
      joinedAt: new Date(),
      status: "waiting",
      notified: false,
    };

    salon.queue.push(client);
    broadcastToSalon(salon.id, { type: "queue_update", queue: buildPublicQueue(salon) });

    res.json({
      client: {
        id: client.id,
        name: client.name,
        position: client.position,
        estimatedWait: client.position * 20,
      },
      salon: { name: salon.name },
      whatsappLink: buildWhatsappMessage(client, salon),
    });
  });

  // GET /api/salons/:id/client/:clientId — statut d'un client
  app.get("/api/salons/:id/client/:clientId", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const client = salon.queue.find(c => c.id === req.params.clientId);
    if (!client) return res.status(404).json({ error: "Client introuvable" });

    const waiting = salon.queue.filter(c => c.status === "waiting");
    const currentPos = waiting.findIndex(c => c.id === client.id) + 1;

    res.json({
      id: client.id,
      name: client.name,
      position: currentPos > 0 ? currentPos : null,
      status: client.status,
      estimatedWait: currentPos > 0 ? currentPos * 20 : 0,
      salonName: salon.name,
    });
  });

  // POST /api/salons/:id/next — coiffeur appelle le suivant
  app.post("/api/salons/:id/next", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const waiting = salon.queue.filter(c => c.status === "waiting");
    if (waiting.length === 0) {
      return res.json({ message: "File vide", called: null });
    }

    const next = waiting[0];
    next.status = "called";
    salon.currentServing++;

    // Renuméroter les restants
    const stillWaiting = salon.queue.filter(c => c.status === "waiting");
    stillWaiting.forEach((c, i) => { c.position = i + 1; });

    broadcastToSalon(salon.id, {
      type: "client_called",
      calledClient: { id: next.id, name: next.name },
      queue: buildPublicQueue(salon),
    });

    res.json({
      called: { id: next.id, name: next.name, phone: next.phone },
      whatsappLink: buildCallWhatsapp(next, salon),
      remaining: stillWaiting.length,
    });
  });

  // POST /api/salons/:id/done/:clientId — marquer comme servi
  app.post("/api/salons/:id/done/:clientId", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const client = salon.queue.find(c => c.id === req.params.clientId);
    if (!client) return res.status(404).json({ error: "Client introuvable" });

    client.status = "done";
    broadcastToSalon(salon.id, { type: "queue_update", queue: buildPublicQueue(salon) });
    res.json({ ok: true });
  });

  // POST /api/salons/:id/remove/:clientId — retirer un client
  app.post("/api/salons/:id/remove/:clientId", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    salon.queue = salon.queue.filter(c => c.id !== req.params.clientId);
    const waiting = salon.queue.filter(c => c.status === "waiting");
    waiting.forEach((c, i) => { c.position = i + 1; });

    broadcastToSalon(salon.id, { type: "queue_update", queue: buildPublicQueue(salon) });
    res.json({ ok: true });
  });

  // POST /api/salons/:id/add — coiffeur ajoute un client manuellement
  app.post("/api/salons/:id/add", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const { name, phone } = req.body;
    if (!name) return res.status(400).json({ error: "Nom requis" });

    const waiting = salon.queue.filter(c => c.status === "waiting");
    const client: Client = {
      id: nanoid(8),
      name: name.trim(),
      phone: phone ? phone.replace(/\D/g, "") : "",
      position: waiting.length + 1,
      joinedAt: new Date(),
      status: "waiting",
      notified: false,
    };

    salon.queue.push(client);
    broadcastToSalon(salon.id, { type: "queue_update", queue: buildPublicQueue(salon) });
    res.json({ client });
  });

  // GET /api/salons/:id/events — SSE pour temps réel
  app.get("/api/salons/:id/events", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).end();

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.flushHeaders();

    // Envoyer l'état initial
    res.write(`data: ${JSON.stringify({ type: "init", queue: buildPublicQueue(salon) })}\n\n`);

    if (!sseClients.has(salon.id)) sseClients.set(salon.id, new Set());
    sseClients.get(salon.id)!.add(res);

    const keepAlive = setInterval(() => {
      try { res.write(": ping\n\n"); } catch { clearInterval(keepAlive); }
    }, 25000);

    req.on("close", () => {
      clearInterval(keepAlive);
      sseClients.get(salon.id)?.delete(res);
    });
  });

  // GET /api/stats/:id — stats du jour pour le dashboard
  app.get("/api/stats/:id", (req, res) => {
    const salon = salons.get(req.params.id);
    if (!salon) return res.status(404).json({ error: "Salon introuvable" });

    const q = salon.queue;
    res.json({
      totalToday: q.length,
      served: q.filter(c => c.status === "done").length,
      waiting: q.filter(c => c.status === "waiting").length,
      called: q.filter(c => c.status === "called").length,
      avgWait: 20, // minutes, fixe pour MVP
    });
  });

  // ─── Helpers ───────────────────────────────────────────────────────────────
  function buildPublicQueue(salon: Salon) {
    return salon.queue
      .filter(c => c.status === "waiting")
      .map((c, i) => ({
        id: c.id,
        name: c.name.split(" ")[0], // prénom seulement
        position: i + 1,
      }));
  }

  function buildWhatsappMessage(client: Client, salon: Salon) {
    const msg = encodeURIComponent(
      `✅ Vous êtes inscrit chez ${salon.name} !\n\n` +
      `📍 Votre position : N°${client.position}\n` +
      `⏱ Temps estimé : ~${client.position * 20} minutes\n\n` +
      `Vous recevrez un message quand c'est votre tour.`
    );
    return `https://wa.me/${client.phone}?text=${msg}`;
  }

  function buildCallWhatsapp(client: Client, salon: Salon) {
    const msg = encodeURIComponent(
      `🔔 C'est votre tour !\n\n` +
      `${client.name}, veuillez vous présenter au ${salon.name} dans les 5 prochaines minutes.\n\n` +
      `Merci ! 🙏`
    );
    return `https://wa.me/${client.phone}?text=${msg}`;
  }

  // ─── Static files ──────────────────────────────────────────────────────────
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;
  server.listen(port, () => {
    console.log(`🚀 SunuQueue server → http://localhost:${port}/`);
    console.log(`   Dashboard coiffeur : /dashboard/salon-demo`);
    console.log(`   Page client QR     : /join/salon-demo`);
  });
}

startServer().catch(console.error);
