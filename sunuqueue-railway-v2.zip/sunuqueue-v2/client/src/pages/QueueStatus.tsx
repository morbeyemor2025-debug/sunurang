import { useState, useEffect, useRef } from "react";
import { useParams } from "wouter";

interface ClientStatus {
  id: string;
  name: string;
  position: number | null;
  status: "waiting" | "called" | "done";
  estimatedWait: number;
  salonName: string;
}

export default function QueueStatus() {
  const { salonId, clientId } = useParams<{ salonId: string; clientId: string }>();
  const [status, setStatus] = useState<ClientStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [queue, setQueue] = useState<{ id: string; name: string; position: number }[]>([]);
  const eventSourceRef = useRef<EventSource | null>(null);

  async function fetchStatus() {
    try {
      const res = await fetch(`/api/salons/${salonId}/client/${clientId}`);
      const data = await res.json();
      setStatus(data);
      setLoading(false);
    } catch {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchStatus();

    // SSE pour les mises à jour en temps réel
    const es = new EventSource(`/api/salons/${salonId}/events`);
    eventSourceRef.current = es;

    es.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === "init" || data.type === "queue_update") {
        setQueue(data.queue || []);
        fetchStatus();
      }
      if (data.type === "client_called" && data.calledClient?.id === clientId) {
        setQueue(data.queue || []);
        fetchStatus();
        // Vibration si supportée
        if ("vibrate" in navigator) navigator.vibrate([200, 100, 200]);
      }
    };

    return () => { es.close(); };
  }, [salonId, clientId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!status) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="text-center">
          <div className="text-5xl mb-3">😕</div>
          <p className="text-gray-600">Impossible de trouver votre position.</p>
        </div>
      </div>
    );
  }

  const isCalled = status.status === "called";
  const isDone = status.status === "done";
  const isFirst = status.position === 1;

  return (
    <div className="min-h-screen flex flex-col" style={{ background: isCalled ? "linear-gradient(160deg, #F0FDF4 0%, #fff 50%)" : "linear-gradient(160deg, #EFF6FF 0%, #fff 60%)" }}>
      {/* Header */}
      <div className="px-6 pt-10 pb-4 text-center">
        <div className="inline-flex items-center gap-2 mb-5 bg-white rounded-full px-4 py-2 shadow-sm border border-gray-100">
          <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center">
            <span className="text-white font-bold text-xs">S</span>
          </div>
          <span className="text-sm font-semibold text-gray-700">{status.salonName}</span>
        </div>
      </div>

      {/* Main status card */}
      <div className="px-6 pb-6">
        <div className="max-w-sm mx-auto">
          {isCalled ? (
            /* ── C'EST VOTRE TOUR ── */
            <div className="bg-green-50 border-2 border-green-400 rounded-2xl p-6 text-center mb-4">
              <div className="text-5xl mb-3 animate-bounce">🔔</div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">C'est votre tour !</h2>
              <p className="text-green-700 text-base mb-4">
                {status.name}, présentez-vous au salon dans les <strong>5 minutes</strong>.
              </p>
              <div className="bg-green-100 rounded-xl p-3 text-sm text-green-700">
                Merci d'être ponctuel pour les autres clients 🙏
              </div>
            </div>
          ) : isDone ? (
            /* ── SERVI ── */
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6 text-center mb-4">
              <div className="text-5xl mb-3">✨</div>
              <h2 className="text-2xl font-bold text-blue-900 mb-2">Merci !</h2>
              <p className="text-blue-700">Vous avez été pris en charge. Bonne journée !</p>
            </div>
          ) : (
            /* ── EN ATTENTE ── */
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 text-center mb-4">
              <p className="text-sm text-gray-500 mb-2">Votre position</p>

              {/* Position badge */}
              <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full mb-4 ${isFirst ? "bg-amber-100 border-4 border-amber-400" : "bg-blue-50 border-4 border-blue-200"}`}>
                <span className={`text-4xl font-bold ${isFirst ? "text-amber-600" : "text-blue-600"}`}>
                  {status.position}
                </span>
              </div>

              {isFirst && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-2 text-sm font-semibold text-amber-700 mb-3 inline-block">
                  🎯 Vous êtes le prochain !
                </div>
              )}

              <h2 className="text-xl font-bold text-gray-900 mb-1">Bonjour {status.name} 👋</h2>

              <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t border-gray-100">
                <div className="text-center">
                  <div className="text-xl font-bold text-gray-900">~{status.estimatedWait}</div>
                  <div className="text-xs text-gray-400">min estimées</div>
                </div>
              </div>
            </div>
          )}

          {/* File d'attente publique */}
          {!isDone && queue.length > 0 && (
            <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-4 mb-4">
              <h3 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse inline-block" />
                File en temps réel
              </h3>
              <div className="space-y-2">
                {queue.slice(0, 6).map((c) => (
                  <div
                    key={c.id}
                    className={`flex items-center gap-3 py-2 px-3 rounded-xl text-sm transition-all ${c.id === clientId ? "bg-blue-50 border border-blue-200 font-semibold" : "bg-gray-50"}`}
                  >
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${c.position === 1 ? "bg-amber-400 text-white" : "bg-gray-200 text-gray-600"}`}>
                      {c.position}
                    </span>
                    <span className={c.id === clientId ? "text-blue-700" : "text-gray-700"}>
                      {c.name} {c.id === clientId ? "(vous)" : ""}
                    </span>
                  </div>
                ))}
                {queue.length > 6 && (
                  <p className="text-xs text-gray-400 text-center pt-1">+{queue.length - 6} autres</p>
                )}
              </div>
            </div>
          )}

          {/* WhatsApp tip */}
          {!isCalled && !isDone && status.position && status.position > 1 && (
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-sm text-gray-500">
                💡 Vous pouvez quitter et revenir. Cette page se met à jour automatiquement.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
