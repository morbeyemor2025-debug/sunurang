import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";

interface SalonInfo {
  id: string;
  name: string;
  waitingCount: number;
  estimatedWait: number;
}

export default function JoinQueue() {
  const { salonId } = useParams<{ salonId: string }>();
  const [, navigate] = useLocation();

  const [salon, setSalon] = useState<SalonInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState("");

  useEffect(() => {
    fetch(`/api/salons/${salonId}`)
      .then(r => r.json())
      .then(d => { setSalon(d); setLoading(false); })
      .catch(() => { setError("Salon introuvable"); setLoading(false); });
  }, [salonId]);

  function validatePhone(val: string) {
    const digits = val.replace(/\D/g, "");
    if (digits.length > 0 && digits.length < 8) {
      setPhoneError("Numéro trop court");
    } else {
      setPhoneError("");
    }
    setPhone(val);
  }

  async function handleJoin(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSubmitting(true);
    setError("");

    try {
      const res = await fetch(`/api/salons/${salonId}/join`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), phone: phone.replace(/\D/g, "") }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      // Redirect to status page
      navigate(`/status/${salonId}/${data.client.id}`);
    } catch (err: any) {
      setError(err.message || "Erreur lors de l'inscription");
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm">Chargement...</p>
        </div>
      </div>
    );
  }

  if (error && !salon) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <div className="text-center max-w-sm">
          <div className="text-5xl mb-4">😕</div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Salon introuvable</h2>
          <p className="text-gray-500 text-sm">Vérifiez le QR Code ou demandez au coiffeur.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "linear-gradient(160deg, #EFF6FF 0%, #fff 60%)" }}>
      {/* Header */}
      <div className="px-6 pt-10 pb-6 text-center">
        <div className="inline-flex items-center gap-2 mb-6 bg-white rounded-full px-4 py-2 shadow-sm border border-gray-100">
          <div className="w-6 h-6 bg-blue-600 rounded-md flex items-center justify-center">
            <span className="text-white font-bold text-xs">S</span>
          </div>
          <span className="text-sm font-semibold text-gray-700">SunuQueue</span>
        </div>

        <h1 className="text-2xl font-bold text-gray-900 mb-1">{salon?.name}</h1>

        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-blue-600">{salon?.waitingCount ?? 0}</div>
            <div className="text-xs text-gray-500 mt-0.5">en attente</div>
          </div>
          <div className="w-px h-10 bg-gray-200" />
          <div className="text-center">
            <div className="text-3xl font-bold text-amber-500">~{salon?.estimatedWait ?? 0}</div>
            <div className="text-xs text-gray-500 mt-0.5">minutes</div>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="flex-1 px-6 pb-10">
        <div className="max-w-sm mx-auto">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-1">Rejoindre la file</h2>
            <p className="text-sm text-gray-500 mb-6">Vous serez notifié sur WhatsApp quand c'est votre tour.</p>

            <form onSubmit={handleJoin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Votre prénom <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="ex: Mamadou"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-gray-900 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Numéro WhatsApp
                  <span className="text-gray-400 font-normal ml-1">(optionnel)</span>
                </label>
                <div className="flex gap-2">
                  <div className="flex items-center px-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-500 text-sm font-medium whitespace-nowrap">
                    🇸🇳 +221
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => validatePhone(e.target.value)}
                    placeholder="77 000 00 00"
                    className="flex-1 px-4 py-3 rounded-xl border border-gray-200 text-gray-900 text-base focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                  />
                </div>
                {phoneError && <p className="text-red-500 text-xs mt-1">{phoneError}</p>}
                <p className="text-xs text-gray-400 mt-1.5">Pour recevoir une notification quand c'est votre tour</p>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting || !name.trim() || !!phoneError}
                className="w-full py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 text-white font-bold text-base rounded-xl transition-all active:scale-95"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Inscription...
                  </span>
                ) : (
                  "✅ Prendre ma place"
                )}
              </button>
            </form>
          </div>

          <p className="text-center text-xs text-gray-400 mt-4">
            En vous inscrivant, vous acceptez d'être contacté sur WhatsApp par le salon.
          </p>
        </div>
      </div>
    </div>
  );
}
